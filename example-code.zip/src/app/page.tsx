import { type Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'

import { ContactSection } from '@/components/ContactSection'
import { Container } from '@/components/Container'
import { FadeIn, FadeInStagger } from '@/components/FadeIn'
import { List, ListItem } from '@/components/List'
import { SectionIntro } from '@/components/SectionIntro'
import { StylizedImage } from '@/components/StylizedImage'
import { Testimonial } from '@/components/Testimonial'
import logoBrightPath from '@/images/clients/bright-path/logo-light.svg'
import logoFamilyFund from '@/images/clients/family-fund/logo-light.svg'
import logoGreenLife from '@/images/clients/green-life/logo-light.svg'
import logoHomeWork from '@/images/clients/home-work/logo-light.svg'
import logoMailSmirk from '@/images/clients/mail-smirk/logo-light.svg'
import logoNorthAdventures from '@/images/clients/north-adventures/logo-light.svg'
import logoPhobiaDark from '@/images/clients/phobia/logo-dark.svg'
import logoPhobiaLight from '@/images/clients/phobia/logo-light.svg'
import logoUnseal from '@/images/clients/unseal/logo-light.svg'
import imageLaptop from '@/images/laptop.jpg'
import { type CaseStudy, type MDXEntry, loadCaseStudies } from '@/lib/mdx'
import { Button } from '@/components/Button'

const clients = [
  ['Phobia', logoPhobiaLight],
  ['Family Fund', logoFamilyFund],
  ['Unseal', logoUnseal],
  ['Mail Smirk', logoMailSmirk],
  ['Home Work', logoHomeWork],
  ['Green Life', logoGreenLife],
  ['Bright Path', logoBrightPath],
  ['North Adventures', logoNorthAdventures],
]

function Clients() {
  return (
    <div className="mt-24 rounded-4xl bg-[#1D63FF] py-20 sm:mt-32 sm:py-32 lg:mt-56">
      <Container>
        <FadeIn className="flex items-center gap-x-8">
          <h2 className="text-center font-display text-sm font-semibold tracking-wider text-white sm:text-left">
            We’ve worked with hundreds of amazing people
          </h2>
          <div className="h-px flex-auto bg-neutral-800" />
        </FadeIn>
        <FadeInStagger faster>
          <ul
            role="list"
            className="mt-10 grid grid-cols-2 gap-x-8 gap-y-10 lg:grid-cols-4"
          >
            {clients.map(([client, logo]) => (
              <li key={client}>
                <FadeIn>
                  <Image src={logo} alt={client} unoptimized />
                </FadeIn>
              </li>
            ))}
          </ul>
        </FadeInStagger>
      </Container>
    </div>
  )
}

function CaseStudies({
  caseStudies,
}: {
  caseStudies: Array<MDXEntry<CaseStudy>>
}) {
  return (
    <>
      <SectionIntro
        title="Harnessing technology for a brighter future"
        className="mt-24 sm:mt-32 lg:mt-40"
      >
        <p>
          We believe technology is the answer to the world’s greatest
          challenges. It’s also the cause, so we find ourselves in bit of a
          catch 22 situation.
        </p>
      </SectionIntro>
      <Container className="mt-16">
        <FadeInStagger className="grid grid-cols-1 gap-8 lg:grid-cols-3">
          {caseStudies.map((caseStudy) => (
            <FadeIn key={caseStudy.href} className="flex">
              <article className="relative flex w-full flex-col rounded-3xl p-6 ring-1 ring-neutral-950/5 transition hover:bg-neutral-50 sm:p-8">
                <h3>
                  <Link href={caseStudy.href}>
                    <span className="absolute inset-0 rounded-3xl" />
                    <Image
                      src={caseStudy.logo}
                      alt={caseStudy.client}
                      className="h-16 w-16"
                      unoptimized
                    />
                  </Link>
                </h3>
                <p className="mt-6 flex gap-x-2 text-sm text-neutral-950">
                  <time
                    dateTime={caseStudy.date.split('-')[0]}
                    className="font-semibold"
                  >
                    {caseStudy.date.split('-')[0]}
                  </time>
                  <span className="text-neutral-300" aria-hidden="true">
                    /
                  </span>
                  <span>Case study</span>
                </p>
                <p className="mt-6 font-display text-2xl font-semibold text-neutral-950">
                  {caseStudy.title}
                </p>
                <p className="mt-4 text-base text-neutral-600">
                  {caseStudy.description}
                </p>
              </article>
            </FadeIn>
          ))}
        </FadeInStagger>
      </Container>
    </>
  )
}

function Services() {
  return (
    <>
      <SectionIntro
        eyebrow="Services"
        title="We help you identify, explore and respond to new challenges."
        className="mt-24 sm:mt-32 lg:mt-40"
      >
        <p>
          Empower your journey using cutting-edge technology. We specialize in
          leveraging innovative solutions to help individuals and businesses
          identify, explore, and conquer emerging challenges.
        </p>
      </SectionIntro>
      <Container className="mt-16">
        <div className="lg:flex lg:items-center lg:justify-end">
          <div className="flex justify-center lg:w-1/2 lg:justify-end lg:pr-12">
            <FadeIn className="w-[33.75rem] flex-none lg:w-[45rem]">
              <StylizedImage
                src={imageLaptop}
                sizes="(min-width: 1024px) 41rem, 31rem"
                className="justify-center lg:justify-end"
              />
            </FadeIn>
          </div>
          <List className="mt-16 lg:mt-0 lg:w-1/2 lg:min-w-[33rem] lg:pl-4">
            <ListItem title="Artificial Intelligence">
              Unlock the potential of Artificial Intelligence with our expert
              services. We offer tailored AI solutions to transform businesses,
              enhance efficiency, and drive innovation. From machine learning to
              advanced analytics, our team specializes in delivering
              cutting-edge AI services that propel you into the future of
              intelligent technology.
            </ListItem>
            <ListItem title="Web development">
              Elevate your online presence with our comprehensive web
              development services. We specialize in crafting dynamic and
              responsive websites tailored to your unique needs. From
              user-friendly interfaces to robust backend solutions, our team
              ensures a seamless and engaging digital experience. Let us bring
              your vision to life on the web.
            </ListItem>
            <ListItem title="Application development">
              Innovate your business with our premier Application Development
              Services. We specialize in crafting tailored solutions, leveraging
              the latest technologies to bring your ideas to life. From
              intuitive user interfaces to robust functionality, our team
              ensures seamless and innovative applications that meet your unique
              needs, fostering success in the digital landscape.
            </ListItem>
            <ListItem title="Cloud Support">
              Embark on a transformative journey with our distinct Cloud Support
              Services. Beyond mere migration and management, we craft
              personalized cloud solutions that resonate with your business
              needs. Elevate efficiency, bolster security, and experience a
              unique approach to cloud optimization, tailored exclusively for
              your success.
            </ListItem>
          </List>
        </div>
      </Container>
    </>
  )
}

export const metadata: Metadata = {
  description:
    'We specialize in crafting custom MVP/SAAS software, applications, and systems to fit your unique business needs. Our expert team ensures innovation, efficiency, and reliability in every solution. Choose us for bespoke IT solutions that align perfectly with your goals and processes.',
}

export default async function Home() {
  let caseStudies = (await loadCaseStudies()).slice(0, 3)

  return (
    <>
      <Container className="mt-24 h-[25rem] sm:mt-32 md:mt-56 md:h-[20rem]">
        <FadeIn className="flex w-full items-center justify-between">
          <div className="max-w-3xl">
            <h1 className="font-display text-4xl font-medium tracking-tight text-neutral-950 [text-wrap:balance] sm:text-7xl">
              We believe in Innovate, Integrate and Elevate
            </h1>
            <p className="mt-6 text-lg text-neutral-600 sm:text-xl">
              We are a custom software development company working at the
              intersection of design and technology, transforming your business
              from start to end.
            </p>
            <div className="mt-6 flex">
              <Button href="/contact" className="hidden px-8 py-5 sm:block">
                Say Hey 👋
              </Button>
              <Button
                href="https://calendly.com/logicleaps/idea-discussion-meeting"
                target="_blank"
                className="!bg-black px-4 py-3 sm:ml-2 sm:px-8 sm:py-5"
              >
                Let Discuss your idea
              </Button>
            </div>
          </div>
        </FadeIn>
      </Container>

      <Testimonial
        className="mt-24 sm:mt-32 lg:mt-40"
        client={{ name: 'Dan Waters (Australia)', logo: logoPhobiaDark }}
      >
        LogicLeaps has truly exceeded expectations in delivering outstanding
        services. Their commitment to excellence is evident in every aspect of
        their work. We highly recommend their services.
      </Testimonial>

      <Services />

      {/* <Clients /> */}

      {/* <CaseStudies caseStudies={caseStudies} /> */}

      <ContactSection />
    </>
  )
}
